<?php $__env->startSection('content'); ?>
<div class="bg-white max-w-lg mx-auto p-6 rounded shadow">
    <h2 class="text-xl font-bold mb-4">Add New Employee</h2>
    <form method="POST" action="/add-employee" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label>First Name</label>
            <input type="text" name="first_name" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label>Last Name</label>
            <input type="text" name="last_name" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label>Email</label>
            <input type="email" name="email" class="w-full border p-2 rounded" required>
        </div>

        <div class="mb-4">
            <label>Upload Image</label>
            <input type="file" name="image" class="w-full border p-2 rounded">
        </div>

        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-800">Add Employee</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', ['title' => 'Add New Employee'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jovel Fabito\laravel-final-project\resources\views/newUserAccount.blade.php ENDPATH**/ ?>