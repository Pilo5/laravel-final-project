<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-md rounded p-6 max-w-sm mx-auto">
    <h2 class="text-xl font-bold mb-4">Login</h2>
    <?php if(session('error')): ?> <p class="text-red-600"><?php echo e(session('error')); ?></p> <?php endif; ?>
    <form method="POST" action="/login">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label>Username</label>
            <input type="text" name="username" required class="w-full border p-2 rounded">
        </div>
        <div class="mb-4">
            <label>Password</label>
            <input type="password" name="password" required class="w-full border p-2 rounded">
        </div>
        <button type="submit" class="bg-blue-700 text-white px-4 py-2 rounded hover:bg-blue-900">Login</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', ['title' => 'Login'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jovel Fabito\laravel-final-project\resources\views/auth/login.blade.php ENDPATH**/ ?>