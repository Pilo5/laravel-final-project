<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-md rounded p-6 max-w-xl mx-auto">
    <div class="flex items-center space-x-4">
        <img src="<?php echo e(asset($user->employee->image_path ?? 'images/default.png')); ?>" class="w-16 h-16 rounded-full" alt="Profile">
        <div>
            <h2 class="text-xl font-semibold"><?php echo e($user->employee->first_name); ?> <?php echo e($user->employee->last_name); ?></h2>
            <p class="text-sm text-gray-600"><?php echo e($user->username); ?></p>
        </div>
    </div>
    <div class="mt-6">
        <a href="/update-password" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">Update Password</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', ['title' => 'User Dashboard'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jovel Fabito\laravel-final-project\resources\views/user/dashboard.blade.php ENDPATH**/ ?>